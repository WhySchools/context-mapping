# context-gen

AST-based context map generator cho Tauri projects.  
Sinh `.context/*.md` từ code thực — không phải viết tay toàn bộ, không phải nhét cả repo vào LLM.

## Vấn đề nó giải quyết

Khi làm TDD với LLM (Claude, DeepSeek, etc.), bạn không muốn:
- Nhét cả repo vào context window → chậm, tốn tiền, model bị "lost in the middle"
- Viết tay context map → stale sau 2 ngày, không ai update

Bạn muốn:
- **Factual (function signatures, types)** → sinh tự động từ AST, luôn đúng
- **Intentional (design decisions, invariants, test strategy)** → viết tay, không bị xóa

context-gen làm đúng điều đó.

## Cài đặt

```bash
pip install -r requirements.txt
```

Hoặc thêm vào `package.json`:
```json
{
  "scripts": {
    "context:build": "python3 tools/context-gen/cli.py build .",
    "context:watch": "python3 tools/context-gen/cli.py watch ."
  }
}
```

## Cách dùng

### Build toàn bộ project
```bash
python3 cli.py build /path/to/your/tauri-project
```

Output:
```
.context/
  GLOBAL.md                           ← overview toàn project
  src-tauri_src_commands.md           ← Tauri IPC commands
  src-tauri_src_core.md               ← business logic
  src-tauri_src_models.md             ← data types
  src_hooks.md                        ← React hooks
  src_types.md                        ← TypeScript types
```

### Chỉ scan một thư mục
```bash
python3 cli.py build . --path src-tauri/src/commands
```

### Load context ra stdout (để pipe vào LLM)
```bash
# Chỉ phần auto (signatures, types) — ~100-200 tokens
python3 cli.py load src-tauri/src/commands .

# Cả auto + manual (đầy đủ nhất để TDD)
python3 cli.py load src-tauri/src/commands . --include-manual

# Copy vào clipboard (macOS)
python3 cli.py load src-tauri/src/commands . --include-manual | pbcopy
```

### Watch mode (auto-regenerate khi save file)
```bash
pip install watchdog
python3 cli.py watch .
```

## Cấu trúc file output

Mỗi `.context/*.md` có 2 vùng được tách bạch rõ ràng:

```markdown
<!-- AUTO_START -->
# Context: `src-tauri/src/commands`

## [auto] Tauri Commands (IPC Bridge)
...sinh tự động từ AST...

## [auto] Public Functions
...

## [auto] Key Imports
...
<!-- AUTO_END -->

<!-- MANUAL_START -->
## [manual] Design Decisions
Viết vào đây — TOOL SẼ KHÔNG XÓA

## [manual] Invariants & Constraints
- Không bao giờ panic!
- Luôn trả AppError, không raw string

## [manual] Test Strategy
...

## [manual] Behavior chưa implement
...
<!-- MANUAL_END -->
```

**Quy tắc vàng**: Tool chỉ regenerate vùng giữa `AUTO_START` và `AUTO_END`.  
Phần `MANUAL_START...MANUAL_END` không bao giờ bị động vào.

## Workflow TDD với LLM

```
1. Bạn thêm hàm mới vào core/ hoặc commands/
2. python3 cli.py build . --path src-tauri/src/commands
3. Mở .context/src-tauri_src_commands.md, điền [manual] Test Strategy
4. python3 cli.py load src-tauri/src/commands . --include-manual | pbcopy
5. Paste vào LLM prompt:
   "Đọc context này. Viết test cho create_invoice theo TDD.
    Tuân thủ invariants trong [manual] section."
6. LLM sinh test đúng behavior vì nó thấy đúng contract
```

## Hỗ trợ

| Language | Files | Trích xuất |
|----------|-------|------------|
| Rust | `.rs` | `pub fn`, `pub async fn`, `#[tauri::command]`, `struct`, `enum`, `use` |
| TypeScript | `.ts` | `export function`, `export async function`, arrow functions |
| TSX | `.tsx` | như TypeScript + React components |

Vue/Svelte: chưa hỗ trợ (`.vue`, `.svelte` bị bỏ qua), planned.

## Tích hợp với git pre-commit

```bash
# .git/hooks/pre-commit
#!/bin/sh
python3 tools/context-gen/cli.py build . --quiet
git add .context/
```

## Cấu trúc project

```
context-gen/
  cli.py              ← entry point (click CLI)
  schema.py           ← dataclasses + marker constants
  merger.py           ← auto/manual merge logic
  global_context.py   ← GLOBAL.md generator
  parsers/
    rust_parser.py    ← tree-sitter-rust
    ts_parser.py      ← tree-sitter-typescript/tsx
```
